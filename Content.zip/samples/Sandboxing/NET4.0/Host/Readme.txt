The project file is generated for VS2010 thus it may need to be migrated if loaded to VS2012. 
This may involve regeneration of the encryption key file.

