SCRIPTING SAMPLES
------------------
Wast majority of the samples are implemented as scripts. If it is required to run/edit the sample files 
with Visual Studio then you will need to right-click the sample (script) file and select in the context menu
CS-Script -> 'Open With VS20##'.

Alternatively you can load and run the samples in Notepad++ with CS-Script plugin enabled.

You can also convert the script into the complete VS project by selecting 'CS-Script' -> 'Convert to' -> 'VS 20## project'  
