using System;

public class Script
{
    public static void Execute()
    {
        ExternalClass.SayHello();
    }
}

