using System;

public class Script
{
	public void Hello(string greeting)
	{
	    Console.WriteLine(greeting);
	}
}

