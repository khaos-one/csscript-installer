using System;
using System.Windows.Forms;

class Script
{
	static public void Print(string message)
	{
		Console.WriteLine(message);
	}
}

