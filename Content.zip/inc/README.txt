User 'include' scripts
------------------
This is a user library of the scripts to be included (referenced) from other scripts. 
Typically this folder contains 'utility' scripts. Anything that can be useful for user. By default this folder contains a few sample scripts. 

For example 'which.cs' script, which allows a quick lookup for a file in the 'well-known' system locations:

Command: css which notepad.exe
Output:  C:\Windows\system32\notepad.exe
   